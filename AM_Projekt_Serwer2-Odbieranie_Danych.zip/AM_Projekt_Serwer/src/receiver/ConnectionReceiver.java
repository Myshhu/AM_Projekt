package receiver;

import user.User;
import user.UserContainer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ConnectionReceiver {

    private ServerSocket serverSocket;
    private Socket clientSocket;
    private UserContainer userContainer;

    private String username;
    private String password;
    private String operation;

    private String WEATHER_INFO = "weatherinfo";
    private String WEATHER_SUCCESS = "weatherdatasentsuccesfully";
    private String CALCULATOR_INFO = "calculatorinfo";
    private String CALCULATOR_SUCCESS = "calculatordatasentsuccesfully";

    public ConnectionReceiver() {
        userContainer = new UserContainer();
    }

    public void startServerSocket() {
        boolean isCreated = createServerSocket();
        if (!isCreated) {
            return;
        }

        try {
            startListening();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean createServerSocket() {
        try {
            serverSocket = new ServerSocket(50005);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private void startListening() throws IOException {
        while (1 != 0) {
            System.out.println("Listening for connection...");

            clientSocket = serverSocket.accept();
            new Thread(() -> {
                try {
                    System.out.println("Connected with " + clientSocket.getInetAddress());

                    BufferedReader br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                    operation = br.readLine();
                    System.out.println("Requested operation " + operation);

                    if (operation.equals("login")) {
                        verifyUser(clientSocket);
                    } else if (operation.equals("register")) {
                        registerUser(clientSocket);
                    } else if (operation.equals(WEATHER_INFO)) {
                        receiveWeatherData(clientSocket);
                    } else if (operation.equals(CALCULATOR_INFO)) {
                        receiveCalculatorData(clientSocket);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }

    private void verifyUser(Socket clientSocket) throws IOException {
        boolean verified = userContainer.verifyUser(username, password);
        BufferedReader br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        username = br.readLine();
        password = br.readLine();
        System.out.println("Received username: " + username + " password: " + password);

        try {
            PrintWriter printWriter = new PrintWriter(clientSocket.getOutputStream(), true);
            if (verified) {
                printWriter.println("verified");
                System.out.println("Verifing user successful: " + username + " password: " + password);

            } else {
                printWriter.println("failed");
                System.out.println("Verifing user failed: " + username + " password: " + password);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void registerUser(Socket clientSocket) throws IOException {
        PrintWriter printWriter;
        BufferedReader br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        username = br.readLine();
        password = br.readLine();
        System.out.println("Received username: " + username + " password: " + password);

        try {
            printWriter = new PrintWriter(clientSocket.getOutputStream(), true);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Registering user failed: " + username + " password: " + password);
            return;
        }

        if (userContainer.containsUser(username, password)) {
            printWriter.println("exists");
            System.out.println("Registering user - user exists: " + username + " password: " + password);
        } else {
            userContainer.addUser(username, password);
            printWriter.println("registered");
            System.out.println("Registering user successful: " + username + " password: " + password);
        }
    }

    private void receiveWeatherData(Socket clientSocket) throws IOException {
        PrintWriter printWriter;
        BufferedReader br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        username = br.readLine();
        String cityName = br.readLine();
        String temperature = br.readLine();
        String pressure = br.readLine();
        String humidity = br.readLine();

        try {
            printWriter = new PrintWriter(clientSocket.getOutputStream(), true);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        System.out.println("Username: " + username + " city: " + cityName + " temp: " + temperature + "C pressure: " + pressure + " humidity: " + humidity);
        printWriter.println(WEATHER_SUCCESS);
    }

    private void receiveCalculatorData(Socket clientSocket) throws IOException {
        BufferedReader br;
        br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        username = br.readLine();
        String firstNumber = br.readLine();
        String secondNumber = br.readLine();
        String operation = br.readLine();
        String result = br.readLine();

        PrintWriter printWriter;
        try {
            printWriter = new PrintWriter(clientSocket.getOutputStream(), true);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        System.out.println("Username: " + username + " firstNumber: " + firstNumber +
                " secondNumber: " + secondNumber + " operation: " + operation + " result: " + result);
        printWriter.println(CALCULATOR_SUCCESS);
    }
}
