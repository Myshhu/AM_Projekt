package receiver;

import user.User;
import user.UserContainer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ConnectionReceiver {

    ServerSocket serverSocket;
    Socket clientSocket;
    UserContainer userContainer;

    String username;
    String password;
    String operation;

    public ConnectionReceiver() {
        userContainer = new UserContainer();
    }

    public void startServerSocket() {
        boolean isCreated = createServerSocket();
        if (!isCreated) {
            return;
        }

        try {
            startListening();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean createServerSocket() {
        try {
            serverSocket = new ServerSocket(50005);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private void startListening() throws IOException {
        while (true) {
            System.out.println("Listening for connection...");
            clientSocket = serverSocket.accept();
            System.out.println("Connected with " + clientSocket.getInetAddress());

            BufferedReader br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            operation = br.readLine();
            username = br.readLine();
            password = br.readLine();
            System.out.println("Received username: " + username + " password: " + password);
            if (operation.equals("login")) {
                verifyUser(username, password, clientSocket);
            } else if (operation.equals("register")) {
                registerUser(username, password, clientSocket);
            }
        }
    }

    private void verifyUser(String username, String password, Socket clientSocket) {
        boolean verified = userContainer.verifyUser(username, password);

        try {
            PrintWriter printWriter = new PrintWriter(clientSocket.getOutputStream(), true);
            if (verified) {
                printWriter.println("verified");
                System.out.println("Verifing user successful: " + username + " password: " + password);

            } else {
                printWriter.println("failed");
                System.out.println("Verifing user failed: " + username + " password: " + password);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void registerUser(String username, String password, Socket clientSocket) {
        PrintWriter printWriter;
        try {
            printWriter = new PrintWriter(clientSocket.getOutputStream(), true);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Registering user failed: " + username + " password: " + password);
            return;
        }

        if (userContainer.containsUser(username, password)) {
            printWriter.println("exists");
            System.out.println("Registering user - user exists: " + username + " password: " + password);
        } else {
            userContainer.addUser(username, password);
            printWriter.println("registered");
            System.out.println("Registering user successful: " + username + " password: " + password);

        }
    }
}
