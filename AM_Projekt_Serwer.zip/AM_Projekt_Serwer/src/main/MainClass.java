package main;

import receiver.ConnectionReceiver;
import user.User;
import user.UserContainer;

import java.util.List;

public class MainClass {
    public static void main(String[] args) {
        printRegisteredUsers();
        new ConnectionReceiver().startServerSocket();
    }

    private static void printRegisteredUsers() {
        List<User> userList = new UserContainer().getUserList();

        for (User user :
                userList) {
            System.out.println("Username: " + user.getUsername() + " ,password: " + user.getPassword());
        }
    }
}
