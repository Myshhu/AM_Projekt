package user;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserContainer {

    private List<User> userList;
    private static String FILE_NAME = "users";

    public UserContainer() {
        userList = readListFromFile();
    }

    public void addUser(String username, String password) {
        User user = new User(username, password);
        userList.add(user);
        saveListToFile();
    }

    public boolean verifyUser(String username, String password) {
        for (User u :
                userList) {
            if (u.getUsername().equals(username)) {
                if (u.getPassword().equals(password)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean containsUser(String username, String password) {
        return userList.stream().anyMatch(o -> o.getUsername().equals(username));
    }

    private List<User> readListFromFile() {
        FileInputStream fileInputStream = null;
        ObjectInputStream objectInputStream = null;
        userList = new ArrayList<>();

        try {
            fileInputStream = new FileInputStream(FILE_NAME);
            objectInputStream = new ObjectInputStream(fileInputStream);
            userList = (List<User>)objectInputStream.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (objectInputStream != null) {
                    objectInputStream.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return userList;
    }

    private void saveListToFile() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(FILE_NAME);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(userList);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<User> getUserList() {
        return userList;
    }

    public void setUserList(List<User> userList) {
        this.userList = userList;
    }
}
